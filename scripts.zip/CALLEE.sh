#!binsh

#Scenarios to simulate call flow

SCENARIO_FILE=<path>/CALLEE.xml
REMOTE_IP_DOMAIN=phone.plivo.com
REMOTE_PORT=5060
LOCAL_IP=
LOCAL_PORT=5060
INJECTION_FILE=<path>/ports.csv
SIPP_EXE=<path>
SERVICE=nas44272190947362782705671
MEDIA_IP=


$SIPP_EXE $REMOTE_IP_DOMAIN$REMOTE_PORT -sf $SCENARIO_FILE -i $LOCAL_IP$LOCAL_PORT -inf $INJECTION_FILE -s SERVICE -mi $MEDIA_IP -m 1 -trace_screen -trace_msg -trace_err -trace_logs
