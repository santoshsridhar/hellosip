#!/bin/sh

#Scenarios to simulate call flow

SCENARIO_FILE=/root/SIPPcalls/REGISTER-callee.xml
REMOTE_IP_DOMAIN=phone.plivo.com
REMOTE_PORT=5060
LOCAL_IP=
LOCAL_PORT=5060
INJECTION_FILE=/root/registerCallee.csv
SIPP_EXE=/root/SIPPcalls/sipp


./$SIPP_EXE $REMOTE_IP_DOMAIN:$REMOTE_PORT -sf $SCENARIO_FILE -i $LOCAL_IP:$LOCAL_PORT -inf $INJECTION_FILE -m 1 -trace_screen -trace_msg -trace_err -trace_logs
