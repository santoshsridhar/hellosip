#!binsh

#Scenarios to simulate call flow

SCENARIO_FILE=<path>/REGISTER.xml
REMOTE_IP_DOMAIN=phone.plivo.com
REMOTE_PORT=5060
LOCAL_IP=192.168.10.1
LOCAL_PORT=5060
INJECTION_FILE=<path>/registerCaller.csv
SIPP_EXE=<path>/sipp


$SIPP_EXE $REMOTE_IP_DOMAIN$REMOTE_PORT -sf SCENARIO_FILE -i $LOCAL_IP$LOCAL_PORT -inf $INJECTION_FILE -m 1 -trace_screen -trace_msg -trace_err -trace_logs
